/**
 * Implementations of different spreadsheet types.
 */
package sheep.sheets;