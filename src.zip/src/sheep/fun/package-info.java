/**
 * <span style="color: #f8981d"><i>(provided)</i></span>
 * Miscellaneous classes to pre-populate spreadsheets.
 */
package sheep.fun;