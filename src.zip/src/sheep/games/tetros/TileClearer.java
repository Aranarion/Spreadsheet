package sheep.games.tetros;

public interface TileClearer {
    void clear();
}
