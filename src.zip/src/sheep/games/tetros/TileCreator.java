package sheep.games.tetros;

public interface TileCreator {
    boolean drop();
}
