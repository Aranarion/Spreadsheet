package sheep.games.tetros;

public interface TileDropper {
    boolean dropTile();
}
