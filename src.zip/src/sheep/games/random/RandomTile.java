package sheep.games.random;

public interface RandomTile {
    int pick();
}
