package sheep.games.random;

import sheep.sheets.CellLocation;

public interface RandomCell {
    CellLocation pick();
}
