/**
 * Expressions that perform basic arithmetic.
 */
package sheep.expression.arithmetic;