/**
 * Expressions within a spreadsheet.
 */
package sheep.expression;