/**
 * Basic types of expressions:
 * empty expressions, constant numbers, and references to other cells.
 */
package sheep.expression.basic;